
<?php 

include 'config.php';
session_start();
if ($_SESSION['is_active'] == true and empty($_GET['json_file']) ==false) {
	include 'ud_photo.php';
	$json = list_pics();
		if (file_exists($global_path.$_GET['json_file']) ==true) {
$res=json_decode(file_get_contents($global_path.$_GET['json_file']),JSON_UNESCAPED_UNICODE);
		if (empty($res) ==false)  {
foreach ($res as $key => $value) {
if(file_exists($global_path.$value)){
	echo unlink($global_path.$value);
}
}
}
}
	
}