<?php 

include 'config.php';
session_start();
if ($_SESSION['is_active'] == true ) {

	echo '<h1>Список модулей</h1>  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="style.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
	body{
		font-family: "Trebuchet MS", sans-serif;
		margin: 50px;
	}
	.demoHeaders {
		margin-top: 2em;
	}
	#dialog-link {
		padding: .4em 1em .4em 20px;
		text-decoration: none;
		position: relative;
	}
	#dialog-link span.ui-icon {
		margin: 0 5px 0 0;
		position: absolute;
		left: .2em;
		top: 50%;
		margin-top: -8px;
	}
	#icons {
		margin: 0;
		padding: 0;
	}
	#icons li {
		margin: 2px;
		position: relative;
		padding: 4px 0;
		cursor: pointer;
		float: left;
		list-style: none;
	}
	#icons span.ui-icon {
		float: left;
		margin: 0 4px;
	}
	.fakewindowcontain .ui-widget-overlay {
		position: absolute;
	}
	select {
		width: 200px;
	}
	</style>';
	if (file_exists($global_path.'like.php')) {
		echo '<ul>Мне нравится(Like)</ul>';
	}

	if (file_exists($global_path.'comment.php')) {
		echo '<ul>Комментарии</ul>';
	}
		if (file_exists($global_path.'data/comments_filter.json')) {
		echo '<ul>Комментарии - Фильтр слов</ul>';
	}

	if (file_exists($global_path.'admin/add_pic.php')) {
		echo '<ul>Изображения - ';
		if (phpversion("gd") ==false) {
echo 'Установите модуль GD для PHP!</ul>';
		}else{
			echo 'Установлен правильно</ul>';
		}
	}
}		