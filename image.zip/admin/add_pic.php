
<?php 

include 'config.php';
session_start();
if ($_SESSION['is_active'] == true ) {
	echo '
  <link rel="stylesheet" type="text/css" href="trix.css">
  <script type="text/javascript" src="trix.js"></script>';
	echo '<h1>Загрузить картинку</h1>';
	echo '  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="style.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
	body{
		font-family: "Trebuchet MS", sans-serif;
		margin: 50px;
	}
	.demoHeaders {
		margin-top: 2em;
	}
	#dialog-link {
		padding: .4em 1em .4em 20px;
		text-decoration: none;
		position: relative;
	}
	#dialog-link span.ui-icon {
		margin: 0 5px 0 0;
		position: absolute;
		left: .2em;
		top: 50%;
		margin-top: -8px;
	}
	#icons {
		margin: 0;
		padding: 0;
	}
	#icons li {
		margin: 2px;
		position: relative;
		padding: 4px 0;
		cursor: pointer;
		float: left;
		list-style: none;
	}
	#icons span.ui-icon {
		float: left;
		margin: 0 4px;
	}
	.fakewindowcontain .ui-widget-overlay {
		position: absolute;
	}
	select {
		width: 200px;
	}
	</style>		<script src="https://github.com/lgarron/clipboard-polyfill/releases/download/v3.0.0-pre5/clipboard-polyfill.promise.js"></script>
';
	echo '<form method="POST" enctype="multipart/form-data">
	<p>Картинка
<input type="file" name="photo_file">
</p> 
<p> <input class="ui-button ui-widget ui-corner-all" type="submit" value="Загрузить" name="">
</p>
	</form>';
	if (empty($_FILES['photo_file']) ==false) {
		include 'ud_photo.php';
		$res=goUd($_FILES);
		if ($res!==false) {
				echo '<div class="ui-widget">
	<div class="ui-state-active ui-corner-all" style="margin-top: 20px; padding: 0 .7em;">
		<p><span class="ui-icon ui-icon-circle-check" style="float: left; margin-right: .3em;"></span>
		<strong>Успех!<p><img src="//'.$_SERVER['SERVER_NAME'].$res['low'].'"/> 
		<p><button class="ui-button ui-widget ui-corner-all" onclick="clipboard.writeText('."'".$_SERVER['SERVER_NAME'].$res['low']."'".' );">Копировать Low-res(320x240)</button></p>
<p><button class="ui-button ui-widget ui-corner-all" onclick="clipboard.writeText('."'".$_SERVER['SERVER_NAME'].$res['mid']."'".' );">Копировать Mid-res(720x480)</button></p>
<p><button class="ui-button ui-widget ui-corner-all" onclick="clipboard.writeText('."'".$_SERVER['SERVER_NAME'].$res['high']."'".' );">Копировать Hi-res(1280x720)</button></p>
<p><button class="ui-button ui-widget ui-corner-all" onclick="clipboard.writeText('."'".$_SERVER['SERVER_NAME'].$res['info']."'".' );">Копировать json</button></p>
		<p> </strong></p>
	</div>
</div>';}else{
		die('<div class="ui-widget">
	<div class="ui-state-error ui-corner-all" style="padding: 0 .7em;">
		<p><span class="ui-icon ui-icon-alert" style="float: left; margin-right: .3em;"></span>
		<strong>Ошибка:</strong> Ошибка загрузки. Скорее всего, неправильно настроены права. Установите права "0777" и владельца на www-data(или на имя другого пользователя кто выполняет скрипты на вашем сервере) </p>
	</div>
</div>');
		}
	}
}