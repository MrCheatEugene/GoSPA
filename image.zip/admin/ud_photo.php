<?php 
	include 'config.php';
function goUd($files_ok){
		include 'config.php';
$_FILES=$files_ok;
$letters = range("a", "z");
$id="";

for ($i=0; $i < 25; $i++) {
$letter =str_replace(array("/",'"','[',']','>','<','?','.'),"",$letters[random_int(0, 25)]);
	$id=$id.$letter.random_int(100,10000);
}
if(file_put_contents($global_path."photo/origin_picture_".$id.'.png',file_get_contents($_FILES['photo_file']['tmp_name']) )){// Извините за подобные извращения, но оно работает. Окей? Всё.
imagepng(imagescale(imagecreatefromstring(file_get_contents($global_path."photo/origin_picture_".$id.'.png')),320,240),$global_path."photo/low_picture_".$id.'.png');
imagepng(imagescale(imagecreatefromstring(file_get_contents($global_path."photo/origin_picture_".$id.'.png')),720,480),$global_path."photo/mid_picture_".$id.'.png');
imagepng(imagescale(imagecreatefromstring(file_get_contents($global_path."photo/origin_picture_".$id.'.png')),1280,720),$global_path."photo/high_picture_".$id.'.png');
	}else{
return false;
	}
  file_put_contents($global_path."photo/info_file_".$id.'.json',json_encode(array('origin'=>"/photo/origin_picture_".$id.'.png','low'=>"/photo/low_picture_".$id.'.png','mid'=>"/photo/mid_picture_".$id.'.png','high'=>"/photo/high_picture_".$id.'.png','info'=>"/photo/info_file_".$id.'.json')),JSON_UNESCAPED_UNICODE);

	return array('origin'=>"/photo/origin_picture_".$id.'.png','low'=>"/photo/low_picture_".$id.'.png','mid'=>"/photo/mid_picture_".$id.'.png','high'=>"/photo/high_picture_".$id.'.png','info'=>"/photo/info_file_".$id.'.json');}
		
function list_pics(){ // опять тупой метод, но все же.
		include 'config.php';
if (file_exists($global_path."photo")) {
	$pics=array();
foreach (scandir($global_path."photo")as $key => $value) {
	if ($value == '.' or $value == '..' ) {
}else{
	if (strpos($value,".json")!==false) {
		$pics[count($pics)+1] = $value;
	}
}
}
return $pics;
}
}