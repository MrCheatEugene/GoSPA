<style type="text/css">	iframe {
    display: block;
    border: none;
    height: 100%;
    width: 100%;
}</style>
<iframe onload='javascript:(function(o){o.style.height=o.contentWindow.document.body.scrollHeight+"px";}(this));' style="height:200px;width:100%;border:none;overflow:hidden;"src="add_pic.php">Ваш браузер не поддерживает Iframe.</iframe>
<iframe onload='javascript:(function(o){o.style.height=o.contentWindow.document.body.scrollHeight+"px";}(this));' style="height:200px;width:100%;border:none;overflow:hidden;" src="list_pics.php">Ваш браузер не поддерживает Iframe.</iframe>