
<?php 

include 'config.php';
session_start();
if ($_SESSION['is_active'] == true ) {
	echo '
  <link rel="stylesheet" type="text/css" href="trix.css">
  <script type="text/javascript" src="trix.js"></script>';
	echo '<h1>Просмотр комментариев</h1>';
		$json = json_decode(file_get_contents($global_path."data/comments.json"),true);
echo '<datalist id="pages">';
foreach ($json as $key => $value) {
echo'<option value="'.$key.'">';
}
echo '</datalist>';
	echo '  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="style.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
	body{
		font-family: "Trebuchet MS", sans-serif;
		margin: 50px;
	}
	.demoHeaders {
		margin-top: 2em;
	}
	#dialog-link {
		padding: .4em 1em .4em 20px;
		text-decoration: none;
		position: relative;
	}
	#dialog-link span.ui-icon {
		margin: 0 5px 0 0;
		position: absolute;
		left: .2em;
		top: 50%;
		margin-top: -8px;
	}
	#icons {
		margin: 0;
		padding: 0;
	}
	#icons li {
		margin: 2px;
		position: relative;
		padding: 4px 0;
		cursor: pointer;
		float: left;
		list-style: none;
	}
	#icons span.ui-icon {
		float: left;
		margin: 0 4px;
	}
	.fakewindowcontain .ui-widget-overlay {
		position: absolute;
	}
	select {
		width: 200px;
	}
	</style>';
	echo '<form action="comments.php">
	<p>Внутреннее имя страницы
<input list="pages" type="text" name="page">
</p> 
<p> <input class="ui-button ui-widget ui-corner-all" type="submit" value="Смотреть комментарии" name="">
</p>
	</form>';
}