
<?php 

include 'config.php';
session_start();
if ($_SESSION['is_active'] == true ) {
$json = json_decode(file_get_contents($global_path."data/comments.json"),true);
if (empty($_GET['page']) ==false and empty($json[$_GET['page']][$_GET['key']]) ==false) {
unset($json[$_GET['page']][$_GET['key']]);
file_put_contents($global_path.'data/comments.json', json_encode($json,JSON_UNESCAPED_UNICODE));
echo 1;
}
}