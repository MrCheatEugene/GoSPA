<?php 
session_start();
include('config.php');
if (isset($_SESSION['is_active']) ==true) {
	echo'
<head>
	<style type="text/css">
	iframe {
    display: block;
    border: none;
    height: 100%;
    width: 100%;
}

</style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Админ-панель - '.$siteName.'</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
  <script>

  $( function() {
    $( "#tabs" ).tabs();
  } );
  </script>
</head>
';
echo'
<div id="tabs">
  <ul>
    <li><a href="#list_pages">Страницы</a></li>
    <li><a href="#action_pages">Действия со страницами</a></li>
    <li><a href="#edit_menu">Редактировать меню</a></li>
        <li><a href="#edit_head">Редактировать header</a></li>
        <li><a href="#modules">Модули</a></li>

';  if (file_exists($global_path.'comment.php')) {
    echo ' <li><a href="#comments">Комментарии</a></li>';
  }echo'
          <li><a href="#" onclick=window.location.href="/">На сайт</a></li>

    <li><a href="logout.php" onclick=window.location.href="logout.php">Выйти</a></li>

  </ul>
  <div id="list_pages">
<iframe src="list_pages.php">Ваш браузер не поддерживает Iframe.</iframe>
</div>
 <div id="action_pages">
<iframe src="actions.php">Ваш браузер не поддерживает Iframe.</iframe>
</div>
<div id="edit_menu">
<iframe src="menu_edit.php">Ваш браузер не поддерживает Iframe.</iframe>
</div>
<div id="edit_head">
<iframe src="head_edit.php">Ваш браузер не поддерживает Iframe.</iframe>
</div>
<div id="modules">
<iframe src="module_list.php">Ваш браузер не поддерживает Iframe.</iframe>
</div>
 ';
 if (file_exists($global_path.'comment.php')) {
    echo ' <div id="comments">
<iframe src="comment.php">Ваш браузер не поддерживает Iframe.</iframe>
</div>';
  }
echo ('');
}else{
header("Location: login.php");
}