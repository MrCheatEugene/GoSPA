<?php 
echo ' <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="style.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
	body{
		font-family: "Trebuchet MS", sans-serif;
		margin: 50px;
	}
	.demoHeaders {
		margin-top: 2em;
	}
	#dialog-link {
		padding: .4em 1em .4em 20px;
		text-decoration: none;
		position: relative;
	}
	#dialog-link span.ui-icon {
		margin: 0 5px 0 0;
		position: absolute;
		left: .2em;
		top: 50%;
		margin-top: -8px;
	}
	#icons {
		margin: 0;
		padding: 0;
	}
	#icons li {
		margin: 2px;
		position: relative;
		padding: 4px 0;
		cursor: pointer;
		float: left;
		list-style: none;
	}
	#icons span.ui-icon {
		float: left;
		margin: 0 4px;
	}
	.fakewindowcontain .ui-widget-overlay {
		position: absolute;
	}
	select {
		width: 200px;
	}
	</style>
	<script src="nicedit.js" type="text/javascript"></script>
<script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>
<form method="POST">
	<h3>Комментарий</h3>
<textarea name="comment" cols="80" rows="5"></textarea>
<p>
<input class="ui-button ui-widget ui-corner-all" type="submit" value="Отправить" name=""></p>
</form>';

if (empty($_POST['comment']) ==false and empty($_GET['page_id']) ==false) {

	include 'admin/config.php';
$json=json_decode(file_get_contents($global_path.'data/comments.json'),true);
if (file_exists($global_path.'data/comments_filter.json')) {
$json_filter=json_decode(file_get_contents($global_path.'data/comments_filter.json'),true);
$_POST['comment']=str_replace($json_filter,"", $_POST['comment']);
}
if (empty($json[$_GET['page_id']]) ==false) {
$json[$_GET['page_id']][count($json[$_GET['page_id']])+1]=$_POST['comment'];
if(file_put_contents($global_path.'data/comments.json', json_encode($json,JSON_UNESCAPED_UNICODE)) ){
	echo '<div class="ui-widget">
	<div class="ui-state-highlight ui-corner-all" style="margin-top: 20px; padding: 0 .7em;">
		<p><span class="ui-icon ui-icon-info" style="float: left; margin-right: .3em;"></span>
		<strong>Успех!</strong></p>
	</div>
</div>';}else{
	die('<div class="ui-widget">
	<div class="ui-state-error ui-corner-all" style="padding: 0 .7em;">
		<p><span class="ui-icon ui-icon-alert" style="float: left; margin-right: .3em;"></span>
		<strong>Ошибка:</strong> Не удалось добавить комментарий</p>
	</div>
</div>');
}
}else{

$json[$_GET['page_id']]=array($_POST['comment']);
if(file_put_contents($global_path.'data/comments.json', json_encode($json,JSON_UNESCAPED_UNICODE)) ){
	echo '<div class="ui-widget">
	<div class="ui-state-highlight ui-corner-all" style="margin-top: 20px; padding: 0 .7em;">
		<p><span class="ui-icon ui-icon-info" style="float: left; margin-right: .3em;"></span>
		<strong>Успех!</strong></p>
	</div>
</div>';}else{
	die('<div class="ui-widget">
	<div class="ui-state-error ui-corner-all" style="padding: 0 .7em;">
		<p><span class="ui-icon ui-icon-alert" style="float: left; margin-right: .3em;"></span>
		<strong>Ошибка:</strong> Не удалось добавить комментарий</p>
	</div>
</div>');
}
}
}
?>
