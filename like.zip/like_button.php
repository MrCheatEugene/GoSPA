<?php 
if (empty($_GET['page']) ==false) {
echo '<script type="text/javascript">
	function Unlike(){
		fetch("like_api.php?page='.$_GET["page"].'&mode=unlike");
		window.location.href=window.location.href;
	}
	function like(){
		fetch("like_api.php?page='.$_GET["page"].'&mode=like");
		window.location.href=window.location.href;
	}
</script>';
include 'like.php';
$state=json_decode(state($_GET['page']),true);
if ($state['result']==true) {
	echo '<button onclick="Unlike()">Больше не нравится</button>';
}else{
	echo '<button onclick="like()">Мне нравится</button>';
}
echo '<br>Всего: '.county($_GET['page']);
}else{
	echo 'Компонент настроен неправильно';
}