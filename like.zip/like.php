<?php

function like($page_id){
	include 'admin/config.php';

if (empty($page_id) ==false ) {
$file=json_decode(file_get_contents($global_path.'data/like.json'),true);
if (empty($file[$_SERVER['REMOTE_ADDR']][$page_id])) {
	$file[$_SERVER['REMOTE_ADDR']][$page_id]=($page_id);
file_put_contents($global_path.'data/like.json', json_encode($file));
		return(json_encode(array('result'=>true)));
}else{
	foreach ($file[$_SERVER['REMOTE_ADDR']] as $key => $value) {
if ($value==$page_id) {
		return( json_encode(array('result'=>false)));
	}	}
}

}
}

function unlike($page_id){
	include 'admin/config.php';

if (empty($page_id) ==false) {
$file=json_decode(file_get_contents($global_path.'data/like.json'),true);
if (empty($file[$_SERVER['REMOTE_ADDR']][$page_id]) ==false) {
	unset($file[$_SERVER['REMOTE_ADDR']][$page_id]);
file_put_contents($global_path.'data/like.json', json_encode($file));
		return json_encode(array('result'=>true));
}else{
		return json_encode(array('result'=>false));
}
}
}
function state($page_id){
	include 'admin/config.php';
if (empty($page_id) ==false ) {
$file=json_decode(file_get_contents($global_path.'data/like.json'),true);
if (empty($file[$_SERVER['REMOTE_ADDR']][$page_id]) ==false) {
		return json_encode(array('result'=>true));
}else{
		return json_encode(array('result'=>false));
}
}
}function county($page_id){
	include 'admin/config.php';
$file=file_get_contents($global_path.'data/like.json');
//тупейший,но рабочий метод
$result=-1;
$count_t=strlen('"'.$page_id.'":'.'"'.$page_id.'"');
for ($i=0; $i < strlen($file); $i+=$count_t) { 
$result+=1;
}
return floor((($result-1)/2));

}