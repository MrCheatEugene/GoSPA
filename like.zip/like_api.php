<?php 	include 'like.php';

if(empty($_GET)==false){
if ($_GET['mode']=='like'){
	die(like($_GET['page']));
}

if ($_GET['mode']=='unlike'){
	die(unlike($_GET['page']));
}
if ($_GET['mode']=='likes'){
	die(county($_GET['page']));
}
}